const waf = (payload)=>{
    payload = payload.toString().replaceAll("'","");
    return payload;
}
module.exports = waf