document.getElementById('login-btn').addEventListener('click', function() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username && password) {
        alert('Login successful');
        // Proceed with login logic
    } else {
        alert('Please enter both username and password');
    }
});
