const express = require('express');
const router = express.Router();
const db = require('../db/connection');
const waf = require('../waf/waf')
const { exec } = require('child_process');
// Define authentication routes
router.post('/login',async (req, res) => {
        const { username, password } = req.body;

        if (!username || !password) {
          return res.status(400).json({ message: 'Username and password are required' });
        }
      
        try {
        //   const [xx] = await db.execute(`SET @my_username:='${waf(username)}' `)
          const [rows] = await db.execute(`SELECT * FROM users WHERE username='${waf(username)}'  and password='${waf(password)}'`);
          console.log(rows)
      
          if (rows.length === 0) {
            return res.status(401).json({ message: 'Invalid credentials' });
          }
      
          const user = rows[0];
          const isMatch = (password == user.password)
      
          if (isMatch) {
            res.status(200).json({ message: 'Login successful' });
          } else {
            res.status(401).json({ message: 'Invalid credentials' });
          }
        } catch (err) {
          console.error(err);
          res.status(500).json({ message: 'Database error', err });
        }
});

router.post('/signup', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }
  
    try {
      const [existingUser] = await db.execute('SELECT * FROM users WHERE username = ?', [username]);
  
      if (existingUser.length > 0) {
        return res.status(409).json({ message: 'Username already exists' });
      }
  
      await db.execute('INSERT INTO users (username, password) VALUES (?, ?)', [username, password]);
  
      res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Database error' });
    }
});

module.exports = router;