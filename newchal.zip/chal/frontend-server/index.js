const express = require('express');
const app = express();
const path = require('path');

// dotenv config

require('dotenv').config();

// constants
const PORT = process.env.PORT || 3000;

// serve static file with express

app.use(express.static(path.join(__dirname, 'static')));

// parse json bodies
app.use(express.json()); 

//routes
const routes = require('./routes/routes');
app.use('/api', routes);


app.listen(process.env.PORT,()=>{
    console.log('Listening on port ',PORT);
})