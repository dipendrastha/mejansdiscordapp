
-- Create the 'chal' database if it doesn't exist
CREATE DATABASE IF NOT EXISTS chal;

-- Switch to the 'chal' database
USE chal;

CREATE TABLE users (
  id INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(40) NOT NULL,
  password VARCHAR(32) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE (username)
);