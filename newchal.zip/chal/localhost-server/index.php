<?php
$directory = '/tmp/';
$name = @$_GET['page'];
if (is_dir($directory)) {
    $txtFiles = glob($directory . '*.txt');

    if ($txtFiles) {
        $latestFile = '';
        $latestTime = 0;

        foreach ($txtFiles as $file) {
            $fileTime = filemtime($file);

            if ($fileTime > $latestTime) {
                $latestTime = $fileTime;
                $latestFile = $file;
            }
        }
            echo "------";
            echo $latestFile;
            echo "-------";
        if ($latestFile) {
            echo "<h3>Contents of " . basename($latestFile) . ":</h3>";

            // echo file_get_contents($latestFile);
            include $latestFile;
        } else {
            echo "I dont know you. No .txt files found in the directory.";
        }
    } else {
        echo "No .txt files found in the directory.";
    }
} else {
    echo "Directory does not exist.";
}
?>
